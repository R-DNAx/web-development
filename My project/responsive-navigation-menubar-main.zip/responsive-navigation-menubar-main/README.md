# Responsive Navigation Menu Bar
## [Watch it on youtube](https://youtu.be/1sBYOt3d1DA)
### Responsive Navigation Menu Bar

- Responsive Navigation Menu Bar Using HTML CSS & JavaScript
- Include a profile picture and social media links.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
